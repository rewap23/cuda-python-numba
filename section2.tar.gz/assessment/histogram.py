# Add your solution here
@cuda.jit
def cuda_histogram(x, xmin, xmax, histogram_out):
    '''Increment bin counts in histogram_out, given histogram range [xmin, xmax).'''
    
    nbins = histogram_out.shape[0]
    bin_width = (xmax - xmin) / nbins
    
    start = cuda.grid(1)
    stride = cuda.gridsize(1)
    
    # This is a very slow way to do this with NumPy, but looks similar to what you will do on the GPU
    for i in range(start, x.shape[0], stride):
        bin_number = np.int32((x[i] - xmin)/bin_width)
        
        if bin_number >= 0 and bin_number < nbins:
            # only increment if in range
            cuda.atomic.add(histogram_out, bin_number, 1)
